// lang_en.php
<?php
$translations = array(
    'Home' => 'Home',
    'About us' => 'About us',
    'Courses' => 'Courses',
    'Teachers' => 'Teachers',
    'Contact us' => 'Contact us',
    'Search courses...' => 'Search courses...',
    'View Profile' => 'View Profile',
    'Login' => 'Login',
    'Register' => 'Register',
    'Logout' => 'Logout',
    'Please login or register' => 'Please login or register'
);
?>
