<footer class="footer">
   

   &copy; copyright @ <?= date('Y'); ?> by <a href="#"><span>Upgrading Education Platform</span></a> | All rights reserved!

</footer>
