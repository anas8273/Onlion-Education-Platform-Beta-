// lang_ar.php
<?php
$translations = array(
    'Home' => 'الصفحة الرئيسية',
    'About us' => 'من نحن',
    'Courses' => 'الدورات',
    'Teachers' => 'المدرسين',
    'Contact us' => 'اتصل بنا',
    'Search courses...' => 'ابحث عن الدورات...',
    'View Profile' => 'عرض الملف الشخصي',
    'Login' => 'تسجيل الدخول',
    'Register' => 'التسجيل',
    'Logout' => 'تسجيل الخروج',
    'Please login or register' => 'الرجاء تسجيل الدخول أو التسجيل'
);
?>
